import json
import sys

import torch


with open(sys.argv[2]) as f:
    jd = json.load(f)
sd = {}
for k, v in jd.items():
    if isinstance(v, list):
        out = torch.Tensor(v)
    else:
        out = torch.Tensor([v]).squeeze(0)
    sd[k] = out
torch.save(sd, sys.argv[1])
